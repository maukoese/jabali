
<!DOCTYPE HTML>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Advanced Player Example</title>

  
    <link rel="stylesheet" href="https://vjs.zencdn.net/5-unsafe/video-js.css">
  
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato&amp;subset=latin,latin-ext">
  
  
    <link rel="stylesheet" href="video.css">
  
    <link rel="stylesheet" href="vertical.css">
  

  <script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-16505296-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

</head>
<body id="advanced_index">

  <section class="main-preview-player">
  <video id="preview-player" class="video-js vjs-big-play-centered vjs-fluid" controls preload="auto" crossorigin="anonymous">
    <p class="vjs-no-js">To view this video please enable JavaScript, and consider upgrading to a web browser that <a href="http://videojs.com/html5-video-support/" target="_blank">supports HTML5 video</a></p>
  </video>

  <div class="playlist-container preview-player-dimensions vjs-fluid">
    <ol class="vjs-playlist"></ol>
  </div>
</section>

    <script src="//vjs.zencdn.net/5-unsafe/video.js"></script>
  
    <script src="mux.js"></script>
  
    <script src="advanced.js"></script>
  
</body>
</html>
